#include <iostream>
#include <cmath>

// Incluir GLAD antes de GLFW
#include "glad.h"
#include <GLFW/glfw3.h>

// Variables globales para la animación
float offset_y = 0.0f;
const float velocidad = 2.0f; // Multiplicador de velocidad para la función sin()
float tiempo_inicio = 0.0f;

// Declaración de vértices del triángulo (en NDC)
float vertices[] = {
    // Coordenadas
    -0.4f, -0.4f, 0.0f, // Inferior Izquierda
     0.4f, -0.4f, 0.0f, // Inferior Derecha
     0.0f,  0.4f, 0.0f  // Superior
};

// Vértice Shader
const char *vertexShaderSource = "#version 330 core\n"
    "layout (location = 0) in vec3 aPos;\n"
    "uniform float uOffsetY;\n" // Uniforme para el desplazamiento
    "void main()\n"
    "{\n"
    "   gl_Position = vec4(aPos.x, aPos.y + uOffsetY, aPos.z, 1.0);\n"
    "}\0";

// Fragment Shader
const char *fragmentShaderSource = "#version 330 core\n"
    "out vec4 FragColor;\n"
    "uniform float uColorBlue;\n" // Uniforme para el color
    "void main()\n"
    "{\n"
    "   FragColor = vec4(1.0f, 0.5f, uColorBlue, 1.0f);\n"
    "}\0";

// Prototipo de funciones
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow *window);
unsigned int compileShader(GLenum type, const char* source);
unsigned int createShaderProgram(const char* vsSource, const char* fsSource);


int main() {
    // 1. Inicialización de GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // 2. Creación de la Ventana
    GLFWwindow* window = glfwCreateWindow(600, 600, "Movimiento con GLAD/GLFW", NULL, NULL);
    if (window == NULL) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // 3. Cargar Funciones de OpenGL (GLAD)
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD" << std::endl;
        return -1;
    }
    
    // 4. Configurar Shaders
    unsigned int shaderProgram = createShaderProgram(vertexShaderSource, fragmentShaderSource);

    // 5. Configurar VBO y VAO (Vertex Array Object)
    unsigned int VBO, VAO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    
    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Enlace de atributos de vértice
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0); 
    glBindVertexArray(0);
    
    // Guardar el tiempo inicial
    tiempo_inicio = glfwGetTime();

    // 6. Bucle de Renderizado Principal
    while (!glfwWindowShouldClose(window)) {
        // Entrada del usuario
        processInput(window);

        // Lógica de la animación
        float tiempo_actual = glfwGetTime();
        // Movimiento senoidal entre -0.5 y 0.5
        offset_y = 0.5f * sin(velocidad * (tiempo_actual - tiempo_inicio));
        
        // El color azul varía con el desplazamiento Y (mapeado de 0 a 1)
        float color_blue = (offset_y + 0.5f) / 1.0f;
        if (color_blue < 0.0f) color_blue = 0.0f;
        if (color_blue > 1.0f) color_blue = 1.0f;

        // Renderizado
        glClearColor(0.1f, 0.1f, 0.2f, 1.0f); // Color de fondo
        glClear(GL_COLOR_BUFFER_BIT);

        // Usar Shaders y actualizar Uniforms
        glUseProgram(shaderProgram);
        
        // 1. Obtener la ubicación del uniforme y actualizar el desplazamiento Y
        int offsetLocation = glGetUniformLocation(shaderProgram, "uOffsetY");
        glUniform1f(offsetLocation, offset_y);

        // 2. Obtener la ubicación del uniforme y actualizar el color azul
        int colorLocation = glGetUniformLocation(shaderProgram, "uColorBlue");
        glUniform1f(colorLocation, color_blue);


        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 3);

        // Intercambiar buffers y revisar eventos
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // 7. Limpieza
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteProgram(shaderProgram);
    glfwTerminate();
    return 0;
}


// --- Implementación de Funciones Auxiliares ---

// Función para el redimensionamiento de la ventana
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// Función para manejar entradas del teclado
void processInput(GLFWwindow *window) {
    if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// Función auxiliar para compilar un Shader
unsigned int compileShader(GLenum type, const char* source) {
    unsigned int shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);

    int success;
    char infoLog[512];
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        std::cerr << "ERROR::SHADER::COMPILATION_FAILED of type " << (type == GL_VERTEX_SHADER ? "VERTEX" : "FRAGMENT") << "\n" << infoLog << std::endl;
    }
    return shader;
}

// Función auxiliar para enlazar los Shaders
unsigned int createShaderProgram(const char* vsSource, const char* fsSource) {
    unsigned int vertexShader = compileShader(GL_VERTEX_SHADER, vsSource);
    unsigned int fragmentShader = compileShader(GL_FRAGMENT_SHADER, fsSource);

    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    int success;
    char infoLog[512];
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cerr << "ERROR::SHADER::LINKING_FAILED\n" << infoLog << std::endl;
    }

    // Ya no se necesitan los shaders individuales una vez enlazados
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return shaderProgram;
}
